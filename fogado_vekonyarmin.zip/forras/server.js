const express = require("express");
const mysql = require("mysql");
const app = express();
const cors = require("cors");
const bodyparser = require("body-parser");
app.use(cors());
app.use(bodyparser.json());

const db = mysql.createConnection(
    {
        user: "root",
        host: "localhost",
        port: "3307",
        password: "",
        database: "fogado"
    }






)

app.get("/", (req, res) => {
    res.send("a szerver működik")
})



app.get("/szobak", (req, res) => {

    const sql = "SELECT 'sznev' AS szoba_nev, agy AS agyak_szama FROM szobak "
    db.query(sql, (err, result) => {
        if (err) return res.json(err);
        return res.json(result);
    }
    )
}
)


app.get("/kihasznaltsag", (req, res) => {

    const sql = "SELECT 'sz.nev' AS szoba_nev, COUNT (f.vendeg) AS vendegek, SUM(DATEDIFF(f.tav,f.erk)) AS vendegejszakak FROM foglalasok f JOIN szobak sz ON f.szoba = sz.szazon GROUP BY sz.sznev ORDER BY vendegejszakak DESC,vendegek ASC"
    db.query(sql, (err, result) => {
        if (err) return res.json(err);
        return res.json(result);
    }
    )
}
)

app.get("/erkezes", (req, res) => {

    const sql = "SELECT 'v.nev' AS nev, 'f.erk' AS erkezes, 'f.tav' AS tavozas FROM 'foglalasok' f JOIN 'vendegek' v ON 'f.vendeg' = 'v.sorsz' WHERE 'f.szoba' = 'szoba_id' ORDER BY 'v.vnev' ASC;"
    db.query(sql, (err, result) => {
        if (err) return res.json(err);
        return res.json(result);
    }
    )
}
)


app.listen(3000, () => {
    console.log('a szerver a 3000 porton fut!')

})