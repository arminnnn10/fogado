import { useState } from 'react'


function App() {
  

  return (
    <>
      <div>
        <h1>Panzió</h1>
       
      </div>
      
      
    </>
  )
}

export default App
